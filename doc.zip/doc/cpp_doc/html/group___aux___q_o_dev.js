var group___aux___q_o_dev =
[
    [ "create_qodev", "group___aux___q_o_dev.html#gafb756f013c57f8b5fc2a070d5f716c45", null ],
    [ "send2circuit", "group___aux___q_o_dev.html#gacf3b1d24bb837feceaba0df05145fa84", null ]
];
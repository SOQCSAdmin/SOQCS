var group___aux___q_o_dev =
[
    [ "create_qodev", "group___aux___q_o_dev.html#ga1bbe08a1ec4b0f6a77b14b142852825d", null ],
    [ "send2circuit", "group___aux___q_o_dev.html#gacf3b1d24bb837feceaba0df05145fa84", null ]
];
var group___photonmdl__management =
[
    [ "photon_mdl", "group___photonmdl__management.html#ga808dd55c4517388b548d20f20834256d", null ],
    [ "photon_mdl", "group___photonmdl__management.html#gabd4c8f126339a4243e302f8f0b43e898", null ],
    [ "~photon_mdl", "group___photonmdl__management.html#ga04612a315991d6465df089cf7966c142", null ],
    [ "clone", "group___photonmdl__management.html#ga081078b7075df7b84351b0d50dcc8fc5", null ]
];
var group___bin__qubit =
[
    [ "translate", "group___bin__qubit.html#ga3e16f99e8f8a27692286392d9e4ab466", null ],
    [ "translate", "group___bin__qubit.html#ga9a980d1c855dacfedf048e604a9f4578", null ]
];
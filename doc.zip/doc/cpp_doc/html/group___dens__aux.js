var group___dens__aux =
[
    [ "create_dmtx", "group___dens__aux.html#ga1294e8a21a5ece79f71371ae9412db02", null ],
    [ "ketcompatible", "group___dens__aux.html#ga9a6ca2302b4a4271872f4fd2168a630c", null ],
    [ "aux_prnt_mtx", "group___dens__aux.html#gabe7f2ad3181ed79ff1821959cd89367c", null ]
];
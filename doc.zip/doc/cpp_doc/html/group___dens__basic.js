var group___dens__basic =
[
    [ "trace", "group___dens__basic.html#ga26e672772c1e94176db41ce3944e5bb8", null ],
    [ "normalize", "group___dens__basic.html#ga022192cc6946c59e4e281fd52c3c7e00", null ],
    [ "add", "group___dens__basic.html#ga0ee26c474ca58e195985913e81fc907b", null ],
    [ "fidelity", "group___dens__basic.html#gab421bdb404b31109f1b4e4348d8dc349", null ],
    [ "get_result", "group___dens__basic.html#ga7e57b24ad1e1c120ffa03214915a1855", null ],
    [ "get_pbin", "group___dens__basic.html#ga6d2e74c3db7bd61ef2a1d6c05dabb9bb", null ]
];
var group___circuit__aux =
[
    [ "create_circuit", "group___circuit__aux.html#gae61f3845d8eff8930e39341d1a7e6eee", null ],
    [ "compute_losses", "group___circuit__aux.html#gafa1fd5e810dc5b0efed0a4fecb98928e", null ]
];
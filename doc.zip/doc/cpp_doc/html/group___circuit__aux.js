var group___circuit__aux =
[
    [ "create_circuit", "group___circuit__aux.html#ga4ea4038dcc242da9f42bbb7a8b9c4385", null ],
    [ "compute_losses", "group___circuit__aux.html#gafa1fd5e810dc5b0efed0a4fecb98928e", null ]
];
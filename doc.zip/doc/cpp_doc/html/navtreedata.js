/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "SOQCS", "index.html", [
    [ "Introduction", "index.html", [
      [ "SOQCS", "index.html#SOQCS", null ],
      [ "Related publications", "index.html#Pub", null ],
      [ "Library structure", "index.html#StructureP", null ],
      [ "Source tree structure", "index.html#FolderP", null ],
      [ "Version release history", "index.html#HistoryP", null ],
      [ "License and copyright", "index.html#lic", null ]
    ] ],
    [ "Compilation and installation", "install.html", [
      [ "Requirements", "install.html#requisites", null ],
      [ "How to build it?", "install.html#build", [
        [ "Step 1: Download the library.", "install.html#step1", null ],
        [ "Step 2: Decompress.", "install.html#step2", null ],
        [ "Step 3: Configure the library.", "install.html#step3", null ],
        [ "Step 4: Build the library.", "install.html#step4", null ]
      ] ],
      [ "How to use it?", "install.html#start", [
        [ "Quick start in C++", "install.html#startcpp", null ],
        [ "Quick start in Python", "install.html#startpython", null ],
        [ "Importing SOQCS to a project", "install.html#advancedstart", null ]
      ] ]
    ] ],
    [ "Starting with SOQCS", "coding.html", [
      [ "Simulating an elementary a circuit.", "coding.html#guidelines", null ],
      [ "Performing an output state calculation.", "coding.html#guidelines2", null ],
      [ "Examples of SOQCS programs", "coding.html#Examples", null ],
      [ "Circuit elements catalog.", "coding.html#catalog", null ],
      [ "Simulator cores/backends", "coding.html#cores", null ]
    ] ],
    [ "Known Issues", "know.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"group___circuit__basic.html#gaaf7dd2ea28560baf3bd5b8a270e957f7",
"group___q_o_dev___circuit__basic.html#gaf5c230d0f4709dadf28d53636182191b",
"state_8h.html#aed307fb74cf06b570d84aadb5b8f36d5"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
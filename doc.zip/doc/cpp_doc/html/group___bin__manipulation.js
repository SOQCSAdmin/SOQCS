var group___bin__manipulation =
[
    [ "calc_measure", "group___bin__manipulation.html#ga9e032eb3f559778b03b20223dada5682", null ],
    [ "post_selection", "group___bin__manipulation.html#ga223542c9aafd866eae7ec69d1d44fb2b", null ],
    [ "dark_counts", "group___bin__manipulation.html#gaa1a6aae130f27e37ebd4b4f7f803940b", null ],
    [ "blink", "group___bin__manipulation.html#gaee1afbd446df627c66bfd7bea310c20e", null ],
    [ "compute_loss", "group___bin__manipulation.html#ga896bf85c7db1c6233366febd25bc8eeb", null ],
    [ "compute_ignored", "group___bin__manipulation.html#ga6d1daedefa5c8f357768b97ccfd916ce", null ],
    [ "remove_channels", "group___bin__manipulation.html#gab23817505d0ab05780730ad869990530", null ],
    [ "compute_cond", "group___bin__manipulation.html#gae2cd0836899a08de1b01c1b9ed05ec0f", null ],
    [ "post_select_cond", "group___bin__manipulation.html#ga2eaed968133ece85431a914d6bfd17ce", null ],
    [ "remove_freq", "group___bin__manipulation.html#gaf681b15613837e6797d28d1b4e93fce7", null ],
    [ "perform_count", "group___bin__manipulation.html#gaff3ba66c2fd7081b12c6c21c23f1d293", null ],
    [ "remove_time", "group___bin__manipulation.html#ga63a9ea8ebf40d92ae77a296fc16b1f45", null ],
    [ "white_noise", "group___bin__manipulation.html#ga04228d9994367a202f5979569bc98427", null ]
];
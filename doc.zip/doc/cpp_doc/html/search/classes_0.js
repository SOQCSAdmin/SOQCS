var searchData=
[
  ['dmatrix',['dmatrix',['../classdmatrix.html',1,'']]]
];

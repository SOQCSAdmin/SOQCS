var searchData=
[
  ['freq',['freq',['../classphoton__mdl.html#a21388731bb22d237aaf05c0a4c9f9ee1',1,'photon_mdl']]]
];

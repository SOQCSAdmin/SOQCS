var searchData=
[
  ['waveplate',['waveplate',['../group___circuit__polar.html#ga71cbb4d0a3525fbd42df4099ba7d267a',1,'qocircuit']]],
  ['white_5fnoise',['white_noise',['../group___bin__manipulation.html#ga04228d9994367a202f5979569bc98427',1,'p_bin']]]
];

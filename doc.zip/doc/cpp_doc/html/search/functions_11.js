var searchData=
[
  ['sample',['sample',['../group___simulation__execution.html#gad45e09f38c6a5b57bb1aedfcb2e1634d',1,'simulator::sample(qodev *input, int N)'],['../group___simulation__execution.html#ga7c1bcb9d5202eb607f776720fc465b79',1,'simulator::sample(state *istate, qocircuit *qoc, int N)']]],
  ['send2circuit',['send2circuit',['../group___aux___q_o_dev.html#gacf3b1d24bb837feceaba0df05145fa84',1,'qodev']]],
  ['send_5fwork',['send_work',['../group___serv__handling.html#ga07fd0d83e2e2057faff4db726addf2f7',1,'mthread']]],
  ['simulator',['simulator',['../group___simulation__management.html#ga1ab0fbd888353e9769fda14ffe5394ac',1,'simulator::simulator()'],['../group___simulation__management.html#ga8fd5544b51c788141b9bfcc2941a3957',1,'simulator::simulator(int i_backend, int i_mem)'],['../group___simulation__management.html#ga628613ca772e5c18948f08484e84bb7b',1,'simulator::simulator(const char *i_back, int i_mem)']]],
  ['state',['state',['../group___state__management.html#gae8b53ef5d217e9ada281315b581478f4',1,'state::state(int i_level)'],['../group___state__management.html#ga47b60384603ef3f7210b2bf0a11f8ca9',1,'state::state(int i_level, int i_maxket)'],['../group___state__management.html#gac97ad13db9cd9c137717587ffdf25d88',1,'state::state(int i_level, int i_maxket, int *i_vis)']]],
  ['str2int',['str2int',['../util_8h.html#ab29c200876205c3add1d71f053195658',1,'util.h']]],
  ['sum_5fstate',['sum_state',['../group___dens__update.html#ga388a45ac722aac46715ef9b8df195d53',1,'dmatrix']]]
];

var searchData=
[
  ['tag',['tag',['../group___bin__consult.html#gaeca95124b60fef804a4beccd43ea63ee',1,'p_bin::tag()'],['../classpysoqcs_1_1p__bin.html#a187809b6037bbbcbe4126c73a9217760',1,'pysoqcs.p_bin.tag()']]],
  ['three_5fgate',['three_gate',['../classpysoqcs_1_1gcircuit.html#affa7b535a5107bd4a3fe3cd618594bef',1,'pysoqcs::gcircuit']]],
  ['to_5fint_5fptr',['to_int_ptr',['../namespacepysoqcs.html#a6e62e282390eee10fe680e3ae2177389',1,'pysoqcs']]],
  ['to_5fint_5fvec',['to_int_vec',['../namespacepysoqcs.html#a10420b43823795b611d9ebf7820ec49a',1,'pysoqcs']]],
  ['trace',['trace',['../group___dens__basic.html#ga26e672772c1e94176db41ce3944e5bb8',1,'dmatrix::trace()'],['../group___bin__basic.html#gac43c32c6e3acfe8f6a4d04427f17a357',1,'p_bin::trace()'],['../classpysoqcs_1_1p__bin.html#a26c4044d405a29c81e61977923e6d755',1,'pysoqcs.p_bin.trace()'],['../classpysoqcs_1_1dmatrix.html#aa4bf45b98e6ac649ed2a480b469dae97',1,'pysoqcs.dmatrix.trace()']]],
  ['translate',['translate',['../group___dens__qubit.html#gad1c924fdb604c789ccce5ec0221d2222',1,'dmatrix::translate(mati qdef, qocircuit *qoc)'],['../group___dens__qubit.html#gaf21938514818a6533d0467ca6dc676f5',1,'dmatrix::translate(mati qdef, qodev *dev)'],['../group___bin__qubit.html#ga3e16f99e8f8a27692286392d9e4ab466',1,'p_bin::translate(mati qdef, qocircuit *qoc)'],['../group___bin__qubit.html#ga9a980d1c855dacfedf048e604a9f4578',1,'p_bin::translate(mati qdef, qodev *dev)'],['../classpysoqcs_1_1p__bin.html#aceb834cde589ac3ad4c477e2087deba1',1,'pysoqcs.p_bin.translate()'],['../classpysoqcs_1_1dmatrix.html#a956bc9ea7ae42f1a4702b6272685ecf2',1,'pysoqcs.dmatrix.translate()']]],
  ['two_5fgate',['two_gate',['../classpysoqcs_1_1gcircuit.html#a2a5a6f14ddeb2ba741067bcf3305ef1e',1,'pysoqcs::gcircuit']]]
];

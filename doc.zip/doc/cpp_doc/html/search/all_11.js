var searchData=
[
  ['r',['R',['../classqocircuit.html#acfe70fc8b89f4485222bf8f2b54650f1',1,'qocircuit']]],
  ['rand_5fpol',['Rand_Pol',['../group___emitter__state.html#ga856e327a4855f8943c3fd2c09a571f88',1,'state']]],
  ['random_5fcircuit',['random_circuit',['../group___circuit__basic.html#gac03ff5a3314367d71d0582462c93f90b',1,'qocircuit::random_circuit()'],['../group___q_o_dev___circuit__basic.html#ga9c6b7790e1a399d9b145226b7710af00',1,'qodev::random_circuit()']]],
  ['receive_5fwork',['receive_work',['../group___serv__handling.html#ga2897a9c2fc6b675f8ecb37ae80b67c7a',1,'mthread']]],
  ['red',['RED',['../util_8h.html#a8d23feea868a983c8c2b661e1e16972f',1,'util.h']]],
  ['relabel',['relabel',['../group___dens__update.html#ga4142264cd8406eef06a86a08a40334e3',1,'dmatrix']]],
  ['remdec',['remdec',['../group___circuit__detector.html#ga3639e66b267804cc07a4c957868d9551',1,'qocircuit']]],
  ['remove_5fchannels',['remove_channels',['../group___bin__manipulation.html#gab23817505d0ab05780730ad869990530',1,'p_bin']]],
  ['remove_5fempty_5fchannels',['remove_empty_channels',['../group___state__operations.html#ga37c2e93c17ca6872c9f0e597b886dac6',1,'state']]],
  ['remove_5ffreq',['remove_freq',['../group___bin__manipulation.html#gaf681b15613837e6797d28d1b4e93fce7',1,'p_bin']]],
  ['remove_5ftime',['remove_time',['../group___bin__manipulation.html#ga63a9ea8ebf40d92ae77a296fc16b1f45',1,'p_bin::remove_time()'],['../group___ket__operations.html#ga2cfef733588e95185ac0d03d98dc9e72',1,'ket_list::remove_time()']]],
  ['repack',['repack',['../group___q_o_dev__initial.html#gab521a4d3d663b5a6ce61bcc86b9d9234',1,'qodev']]],
  ['rephase',['rephase',['../group___state__operations.html#ga840ae61cdf58ca4c16996b8efc7bdc99',1,'state']]],
  ['reset',['reset',['../group___circuit__management.html#ga649562443c8727bb4431772f03d4dc5a',1,'qocircuit::reset()'],['../group___q_o_dev__management.html#gaa1add88a964ef5d4110b4e36cbe73a14',1,'qodev::reset()'],['../util_8h.html#ab702106cf3b3e96750b6845ded4e0299',1,'RESET():&#160;util.h']]],
  ['return_5fpacket_5fdef',['return_packet_def',['../group___photonmdl__utility.html#ga653f3bcda2d02cdad9c6bb0b642dbd8c',1,'photon_mdl']]],
  ['rewire',['rewire',['../group___circuit__basic.html#ga4982f3c2f1b3061533627f104f1b9bf0',1,'qocircuit::rewire()'],['../group___q_o_dev___circuit__basic.html#gaf5c230d0f4709dadf28d53636182191b',1,'qodev::rewire()']]],
  ['rotator',['rotator',['../group___circuit__polar.html#ga7500d115113245b8e62e91d26be4ec78',1,'qocircuit::rotator()'],['../group___q_o_dev___circuit__polar.html#ga6734ee0e82e61681e42e6935c50a6247',1,'qodev::rotator()']]],
  ['run',['run',['../group___simulation__execution.html#ga8568dc4c6439965e9b0a3636d6ec320a',1,'simulator::run(qodev *circuit)'],['../group___simulation__execution.html#gae0f4d9cb28e4bdb76dd95c46dab695f0',1,'simulator::run(state *istate, qocircuit *qoc)'],['../group___simulation__execution.html#gaa697512a8b6d3e023472c1e04e97fa30',1,'simulator::run(state *istate, ket_list *olist, qocircuit *qoc)']]]
];

var searchData=
[
  ['pysoqcs',['pysoqcs',['../namespacepysoqcs.html',1,'']]]
];

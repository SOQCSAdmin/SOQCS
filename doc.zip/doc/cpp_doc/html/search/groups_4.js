var searchData=
[
  ['initialization_20methods',['Initialization methods',['../group___emitter__state.html',1,'']]]
];

var searchData=
[
  ['starting_20with_20soqcs',['Starting with SOQCS',['../coding.html',1,'']]]
];

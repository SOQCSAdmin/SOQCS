var searchData=
[
  ['sample',['sample',['../group___simulation__execution.html#gad45e09f38c6a5b57bb1aedfcb2e1634d',1,'simulator::sample(qodev *input, int N)'],['../group___simulation__execution.html#ga7c1bcb9d5202eb607f776720fc465b79',1,'simulator::sample(state *istate, qocircuit *qoc, int N)'],['../classpysoqcs_1_1simulator.html#a33b6784d87557a4b4ff09b0eeb1a98e8',1,'pysoqcs.simulator.sample()']]],
  ['sample_5fst',['sample_st',['../classpysoqcs_1_1simulator.html#a5a110e0d3511ace3e41fea7174de8da0',1,'pysoqcs::simulator']]],
  ['send2circuit',['send2circuit',['../group___aux___q_o_dev.html#gacf3b1d24bb837feceaba0df05145fa84',1,'qodev']]],
  ['send_5fwork',['send_work',['../group___serv__handling.html#ga3275d9ce4fb9199d6dbb5da64f103e71',1,'mthread']]],
  ['separator',['separator',['../classpysoqcs_1_1gcircuit.html#a92a5861d4643f6bcb53b47c35bf0a9ed',1,'pysoqcs.gcircuit.separator()'],['../classpysoqcs_1_1qodev.html#a581b69547b48ab347992e269bce3a88f',1,'pysoqcs.qodev.separator()']]],
  ['show',['show',['../classpysoqcs_1_1p__bin.html#a7e759758f75143a3a0c07ca440729028',1,'pysoqcs.p_bin.show()'],['../classpysoqcs_1_1gcircuit.html#a0a799dc146f2fa6bb57c30580d6e9bcf',1,'pysoqcs.gcircuit.show()'],['../classpysoqcs_1_1qodev.html#a43651f822692399024020c9e4d1e9a89',1,'pysoqcs.qodev.show()']]],
  ['sign',['sign',['../util_8h.html#a287eba75300a059df1f02fd4fc6b8cbd',1,'util.h']]],
  ['simulator',['simulator',['../group___simulation__management.html#ga1ab0fbd888353e9769fda14ffe5394ac',1,'simulator::simulator()'],['../group___simulation__management.html#ga16f1e8655e55a27edfcdd7b1b32df648',1,'simulator::simulator(int i_mem)']]],
  ['state',['state',['../group___state__management.html#gae8b53ef5d217e9ada281315b581478f4',1,'state::state(int i_level)'],['../group___state__management.html#ga47b60384603ef3f7210b2bf0a11f8ca9',1,'state::state(int i_level, int i_maxket)'],['../group___state__management.html#gac97ad13db9cd9c137717587ffdf25d88',1,'state::state(int i_level, int i_maxket, int *i_vis)']]],
  ['str2int',['str2int',['../util_8h.html#ab29c200876205c3add1d71f053195658',1,'util.h']]],
  ['sum_5fstate',['sum_state',['../group___dens__update.html#ga388a45ac722aac46715ef9b8df195d53',1,'dmatrix']]]
];

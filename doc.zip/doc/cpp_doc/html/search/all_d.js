var searchData=
[
  ['n',['N',['../classdmatrix.html#a91ce93b16713d8e53b238176a6533a7d',1,'dmatrix::N()'],['../classp__bin.html#a2dd57a8d524c9149f4e536a0ad5a6ae2',1,'p_bin::N()'],['../live4_8cpp.html#ab2b6b0c222cd1ce70d6a831f57241e59',1,'N():&#160;live4.cpp'],['../live6_8cpp.html#ab2b6b0c222cd1ce70d6a831f57241e59',1,'N():&#160;live6.cpp'],['../live8_8cpp.html#ab2b6b0c222cd1ce70d6a831f57241e59',1,'N():&#160;live8.cpp']]],
  ['nch',['nch',['../classqocircuit.html#aa8437409028133e33a2bdb6749416ce1',1,'qocircuit']]],
  ['ncond',['ncond',['../classqocircuit.html#a0368d16c846b5be68f77bd6b261bb0f5',1,'qocircuit']]],
  ['ndetc',['ndetc',['../classqocircuit.html#a6ea8006153af2511d1b3820f98b78f6d',1,'qocircuit']]],
  ['new_5fthread',['new_thread',['../group___serv__handling.html#ga2c53563f33bd92e47bd17a75c321aad5',1,'new_thread(state *input, qocircuit *qoc, simulator *sim, int method, promise&lt; qelem &gt; p):&#160;mthread.cpp'],['../group___serv__handling.html#ga2c53563f33bd92e47bd17a75c321aad5',1,'new_thread(state *input, qocircuit *qoc, simulator *sim, int method, promise&lt; qelem &gt; p):&#160;mthread.cpp']]],
  ['nformats',['NFORMATS',['../state_8h.html#a72436de39b9a64f7a4f3f753ae45e696',1,'state.h']]],
  ['nignored',['nignored',['../classqocircuit.html#a6f33f0414af17a933c882ae23d083e11',1,'qocircuit']]],
  ['nket',['nket',['../classket__list.html#a13a08651670e6f514a4622afe8e103c1',1,'ket_list']]],
  ['nlevel',['nlevel',['../classqocircuit.html#a6080b0aac800d959bd620dc615f0497a',1,'qocircuit::nlevel()'],['../classket__list.html#aaf8cdef16edf8b721a0c6e7a8ad00808',1,'ket_list::nlevel()']]],
  ['nm',['nm',['../classqocircuit.html#ac944a8406345728d86a2e04e06846ad8',1,'qocircuit']]],
  ['noise',['noise',['../group___circuit__detector.html#ga067a409ebaa03244c1bc76455bf0f2bf',1,'qocircuit::noise()'],['../group___q_o_dev___circuit__detector.html#ga2be5d0e4897a6b2e0a56f799e2b1e54e',1,'qodev::noise()']]],
  ['normalize',['normalize',['../group___dens__basic.html#ga022192cc6946c59e4e281fd52c3c7e00',1,'dmatrix::normalize()'],['../group___bin__basic.html#ga8dd3f362bc3e13b904d54d836b7ac59f',1,'p_bin::normalize()'],['../group___state__operations.html#ga4d2314d1901dd447edba78b78137ddfb',1,'state::normalize()']]],
  ['np',['np',['../classqocircuit.html#ac42fed28f662b80c48c150025c36f977',1,'qocircuit']]],
  ['npack',['npack',['../classqocircuit.html#ad24c79171e91406254af9ed2e8013fec',1,'qocircuit::npack()'],['../classqodev.html#a1db2eabe26d7d4289b73f12d71494ab6',1,'qodev::npack()']]],
  ['nph',['nph',['../classket__list.html#a4e48a6bcb98d4465956d3bce020e596f',1,'ket_list']]],
  ['ns',['ns',['../classqocircuit.html#a43caf667040edf7c0419b584fb91a262',1,'qocircuit']]],
  ['nsp',['nsp',['../classqocircuit.html#ae617d455269769691e94627a33b82919',1,'qocircuit']]],
  ['nsx',['NSX',['../group___circuit__basic.html#gac1618d8b7de08163ce20aa6e7e2317a3',1,'qocircuit::NSX()'],['../group___q_o_dev___circuit__basic.html#ga33425c954c5abd319fddb3e54e52a763',1,'qodev::NSX()']]],
  ['num_5flevels',['num_levels',['../group___circuit__management.html#ga66910adf79c4574c2a3d42002336d40d',1,'qocircuit']]]
];

var searchData=
[
  ['r',['R',['../classqocircuit.html#acfe70fc8b89f4485222bf8f2b54650f1',1,'qocircuit']]]
];

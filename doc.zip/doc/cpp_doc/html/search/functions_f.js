var searchData=
[
  ['one_5fgate',['one_gate',['../classpysoqcs_1_1gcircuit.html#a3f0648c6713f7962f0b0ef5c35eedc02',1,'pysoqcs::gcircuit']]],
  ['open_5fchannel',['open_channel',['../classpysoqcs_1_1qodev.html#ad472d2269695c74a45c7f4660fbdbfe7',1,'pysoqcs::qodev']]]
];

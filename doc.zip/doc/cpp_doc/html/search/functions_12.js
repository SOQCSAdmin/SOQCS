var searchData=
[
  ['tag',['tag',['../group___bin__consult.html#gaeca95124b60fef804a4beccd43ea63ee',1,'p_bin']]],
  ['trace',['trace',['../group___dens__basic.html#ga26e672772c1e94176db41ce3944e5bb8',1,'dmatrix::trace()'],['../group___bin__basic.html#gac43c32c6e3acfe8f6a4d04427f17a357',1,'p_bin::trace()']]],
  ['translate',['translate',['../group___bin__qubit.html#ga3e16f99e8f8a27692286392d9e4ab466',1,'p_bin::translate(mati qdef, qocircuit *qoc)'],['../group___bin__qubit.html#ga9a980d1c855dacfedf048e604a9f4578',1,'p_bin::translate(mati qdef, qodev *dev)']]]
];

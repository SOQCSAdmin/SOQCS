var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxy~",
  1: "adgklmpqs",
  2: "p",
  3: "dlmpqsu",
  4: "_abcdefghijklmnopqrstuvw~",
  5: "acdefhiklmnopqrstvwx",
  6: "chmtv",
  7: "bcgmrwy",
  8: "bcdeiklmpqs",
  9: "ciks"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "defines",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Macros",
  8: "Modules",
  9: "Pages"
};


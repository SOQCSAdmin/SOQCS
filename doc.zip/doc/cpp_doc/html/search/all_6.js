var searchData=
[
  ['gauss_5fcoup',['gauss_coup',['../util_8cpp.html#a3559b0b9957d7ee601349340a64e19f9',1,'gauss_coup(double ti, double wi, double dwi, double tj, double wj, double dwj, double tri, double trj):&#160;util.cpp'],['../util_8h.html#a3559b0b9957d7ee601349340a64e19f9',1,'gauss_coup(double ti, double wi, double dwi, double tj, double wj, double dwj, double tri, double trj):&#160;util.cpp']]],
  ['get_5fcounts',['get_counts',['../group___dens__update.html#gaf26b220adf15b60de05e3b2da90a9eb6',1,'dmatrix']]],
  ['get_5fpbin',['get_pbin',['../group___dens__basic.html#ga6d2e74c3db7bd61ef2a1d6c05dabb9bb',1,'dmatrix']]],
  ['get_5fresult',['get_result',['../group___dens__basic.html#ga7e57b24ad1e1c120ffa03214915a1855',1,'dmatrix']]],
  ['glynn',['glynn',['../util_8cpp.html#a95b1dbaf62b9d6c9d6982c47637b8629',1,'glynn(matc M):&#160;util.cpp'],['../util_8h.html#a95b1dbaf62b9d6c9d6982c47637b8629',1,'glynn(matc M):&#160;util.cpp']]],
  ['glynnf',['GlynnF',['../group___simulation__auxiliary.html#ga15b85c4bcce11315fef08e1061a09199',1,'simulator']]],
  ['glynnr',['GlynnR',['../group___simulation__auxiliary.html#gad95ac0aafcffadcfcf1ba64519be3bdf',1,'simulator']]],
  ['glynns',['GlynnS',['../group___simulation__auxiliary.html#ga8ef74a30369989f8215b528c834732d1',1,'simulator']]],
  ['grand',['grand',['../util_8cpp.html#a9c546404a5972f369226eff1302e0f3e',1,'grand(double mu, double stdev):&#160;util.cpp'],['../util_8h.html#a9c546404a5972f369226eff1302e0f3e',1,'grand(double mu, double stdev):&#160;util.cpp']]],
  ['green',['GREEN',['../util_8h.html#acfbc006ea433ad708fdee3e82996e721',1,'util.h']]],
  ['gsp',['GSP',['../util_8cpp.html#a05e7be0c1bb61badb4e6a8d1a32f50e9',1,'GSP(matc S):&#160;util.cpp'],['../util_8h.html#a05e7be0c1bb61badb4e6a8d1a32f50e9',1,'GSP(matc S):&#160;util.cpp']]]
];

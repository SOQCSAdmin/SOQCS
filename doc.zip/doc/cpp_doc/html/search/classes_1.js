var searchData=
[
  ['dmatrix',['dmatrix',['../classdmatrix.html',1,'dmatrix'],['../classpysoqcs_1_1dmatrix.html',1,'pysoqcs.dmatrix']]]
];

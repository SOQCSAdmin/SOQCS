var searchData=
[
  ['loss',['loss',['../group___circuit__basic.html#ga3b9441da86651a4270cf3db84afae9db',1,'qocircuit::loss()'],['../group___q_o_dev___circuit__basic.html#ga7083236a53a6952821321c956663ce0f',1,'qodev::loss()']]]
];

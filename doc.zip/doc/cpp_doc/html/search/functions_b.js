var searchData=
[
  ['loss',['loss',['../group___circuit__basic.html#gab2c910078ee7d5d287762db392e76340',1,'qocircuit::loss()'],['../group___q_o_dev___circuit__basic.html#ga688b6fa744e3392d40f4865012216fe0',1,'qodev::loss()']]]
];

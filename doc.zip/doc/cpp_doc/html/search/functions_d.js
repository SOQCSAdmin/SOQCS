var searchData=
[
  ['new_5fthread',['new_thread',['../group___serv__handling.html#ga1c2b5558328fe38d024f2391229639f9',1,'new_thread(state *input, simulator *sim, qocircuit *qoc, promise&lt; qelem &gt; p):&#160;mthread.cpp'],['../group___serv__handling.html#ga1c2b5558328fe38d024f2391229639f9',1,'new_thread(state *input, simulator *sim, qocircuit *qoc, promise&lt; qelem &gt; p):&#160;mthread.cpp']]],
  ['noise',['noise',['../group___circuit__detector.html#ga067a409ebaa03244c1bc76455bf0f2bf',1,'qocircuit::noise()'],['../group___q_o_dev___circuit__detector.html#ga2be5d0e4897a6b2e0a56f799e2b1e54e',1,'qodev::noise()']]],
  ['normalize',['normalize',['../group___dens__basic.html#ga022192cc6946c59e4e281fd52c3c7e00',1,'dmatrix::normalize()'],['../group___bin__basic.html#ga8dd3f362bc3e13b904d54d836b7ac59f',1,'p_bin::normalize()'],['../group___state__operations.html#ga4d2314d1901dd447edba78b78137ddfb',1,'state::normalize()']]],
  ['nsx',['NSX',['../group___circuit__basic.html#gab07f26a3edee94d43dee25f9243c7022',1,'qocircuit::NSX()'],['../group___q_o_dev___circuit__basic.html#gabf5f0e3b3b60647b1d9b84ece2f8ad3f',1,'qodev::NSX()']]],
  ['num_5flevels',['num_levels',['../group___circuit__management.html#ga66910adf79c4574c2a3d42002336d40d',1,'qocircuit']]]
];

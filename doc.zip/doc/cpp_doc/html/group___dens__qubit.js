var group___dens__qubit =
[
    [ "translate", "group___dens__qubit.html#gad1c924fdb604c789ccce5ec0221d2222", null ],
    [ "translate", "group___dens__qubit.html#gaf21938514818a6533d0467ca6dc676f5", null ],
    [ "pol_translate", "group___dens__qubit.html#ga077eba6a63b9bcbccda098be96533df7", null ],
    [ "pol_translate", "group___dens__qubit.html#ga2d305061887e4c3f8a0fad7357975f11", null ]
];
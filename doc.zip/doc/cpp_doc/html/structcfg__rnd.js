var structcfg__rnd =
[
    [ "dt1", "structcfg__rnd.html#a529c882dd7b1d7b5c9ee11bb1d928148", null ],
    [ "dt2", "structcfg__rnd.html#a514b3517b316196c7603dfcb6c57b166", null ]
];
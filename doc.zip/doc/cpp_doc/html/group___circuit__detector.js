var group___circuit__detector =
[
    [ "ignore", "group___circuit__detector.html#ga54c1d3fd394fff5281af93eb9ce32448", null ],
    [ "detector", "group___circuit__detector.html#gab6c7c1f6c9839a5b152edcd81b7849d9", null ],
    [ "detector", "group___circuit__detector.html#ga3f476533496b6283e5fdc1690ff267ae", null ],
    [ "detector", "group___circuit__detector.html#ga10141afccfa0c123642d71124c323b41", null ],
    [ "detector", "group___circuit__detector.html#gaff9cdc8b5b14a6ee2df975b683031a11", null ],
    [ "remdec", "group___circuit__detector.html#ga3639e66b267804cc07a4c957868d9551", null ],
    [ "noise", "group___circuit__detector.html#ga067a409ebaa03244c1bc76455bf0f2bf", null ]
];
var group___q_o_dev___circuit =
[
    [ "Basic device elements", "group___q_o_dev___circuit__basic.html", "group___q_o_dev___circuit__basic" ],
    [ "Device polarization elements", "group___q_o_dev___circuit__polar.html", "group___q_o_dev___circuit__polar" ],
    [ "Detectors", "group___q_o_dev___circuit__detector.html", "group___q_o_dev___circuit__detector" ]
];
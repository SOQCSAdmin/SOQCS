var group___serv__management =
[
    [ "mthread", "group___serv__management.html#gac47284765cff18d075b2664bec42905d", null ],
    [ "~mthread", "group___serv__management.html#gab6bc6f5e4742d3d78f2681c027e30f34", null ]
];
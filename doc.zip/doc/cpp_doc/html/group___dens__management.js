var group___dens__management =
[
    [ "dmatrix", "group___dens__management.html#ga7ace3d2d0e9c7c13e841a7a9911af7d5", null ],
    [ "dmatrix", "group___dens__management.html#ga7d87792e72520772eb0b0837331e5357", null ],
    [ "~dmatrix", "group___dens__management.html#ga19683414b8132c02474b8cfebc615795", null ],
    [ "clone", "group___dens__management.html#gac61c2df12b8cd511b22ddbaf841d9fd4", null ],
    [ "clear", "group___dens__management.html#gad39e801af495508d754708f9e04052a7", null ]
];
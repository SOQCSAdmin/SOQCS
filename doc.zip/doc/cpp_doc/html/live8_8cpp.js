var live8_8cpp =
[
    [ "main", "live8_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "N", "live8_8cpp.html#ab2b6b0c222cd1ce70d6a831f57241e59", null ],
    [ "prntn", "live8_8cpp.html#abf3594933a9cef13ea9e06fddb37644b", null ]
];
var structqelem =
[
    [ "input", "structqelem.html#a549bcba0adacc3280ad5c2e309793b7e", null ],
    [ "output", "structqelem.html#af0566251e79541f801e0c74548ef4350", null ],
    [ "qoc", "structqelem.html#a3f4aa0ab9d3a83583be401802c6d9c5c", null ]
];
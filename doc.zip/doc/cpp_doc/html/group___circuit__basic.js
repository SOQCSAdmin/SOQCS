var group___circuit__basic =
[
    [ "random_circuit", "group___circuit__basic.html#gac03ff5a3314367d71d0582462c93f90b", null ],
    [ "NSX", "group___circuit__basic.html#gac1618d8b7de08163ce20aa6e7e2317a3", null ],
    [ "beamsplitter", "group___circuit__basic.html#ga3458345ed43a3002ee67c5c712984fda", null ],
    [ "dielectric", "group___circuit__basic.html#ga9d01ba40e39c2e440b14581e0cc91ddc", null ],
    [ "MMI2", "group___circuit__basic.html#ga592d5451c0c00344c2d83abf0d760970", null ],
    [ "rewire", "group___circuit__basic.html#ga4982f3c2f1b3061533627f104f1b9bf0", null ],
    [ "phase_shifter", "group___circuit__basic.html#gaaf7dd2ea28560baf3bd5b8a270e957f7", null ],
    [ "phase_shifter", "group___circuit__basic.html#ga38411e62beb281fe2785f9e8064b018f", null ],
    [ "dispersion", "group___circuit__basic.html#gac4447201219ce12454a38ee089e15c5a", null ],
    [ "dispersion", "group___circuit__basic.html#ga545b54c283894ea6940357ab9aa96b57", null ],
    [ "loss", "group___circuit__basic.html#gab2c910078ee7d5d287762db392e76340", null ],
    [ "custom_gate", "group___circuit__basic.html#gaf4c9926e8211b07eca030078ea57095b", null ]
];
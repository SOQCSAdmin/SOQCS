var group___circuit__basic =
[
    [ "random_circuit", "group___circuit__basic.html#gac03ff5a3314367d71d0582462c93f90b", null ],
    [ "NSX", "group___circuit__basic.html#gab07f26a3edee94d43dee25f9243c7022", null ],
    [ "beamsplitter", "group___circuit__basic.html#gac02f79267b58e219a65e4baf25410e28", null ],
    [ "dielectric", "group___circuit__basic.html#ga12d017d5f3380dd6d4e91836458206d7", null ],
    [ "MMI2", "group___circuit__basic.html#ga4b6476ec2eab33d466889238d876ee46", null ],
    [ "rewire", "group___circuit__basic.html#ga9b6aada1c798992e1efb83d0f972639f", null ],
    [ "phase_shifter", "group___circuit__basic.html#ga42a4f680611df9e3605c7fd42dbb3e75", null ],
    [ "dispersion", "group___circuit__basic.html#gacd9ca77343bf070d0f006c2d6ac759a8", null ],
    [ "dispersion", "group___circuit__basic.html#ga8cf5e756defb696be2914d0621e2a7b1", null ],
    [ "phase_shifter", "group___circuit__basic.html#gaf3549564c11a90b859a3807098b35e62", null ],
    [ "loss", "group___circuit__basic.html#ga3b9441da86651a4270cf3db84afae9db", null ],
    [ "custom_gate", "group___circuit__basic.html#gaa85f6698cb6531924ccbb8f187f1afbc", null ]
];
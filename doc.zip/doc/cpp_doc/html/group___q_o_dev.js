var group___q_o_dev =
[
    [ "Device management", "group___q_o_dev__management.html", "group___q_o_dev__management" ],
    [ "Device initial state", "group___q_o_dev__initial.html", "group___q_o_dev__initial" ],
    [ "Device elements", "group___q_o_dev___circuit.html", "group___q_o_dev___circuit" ],
    [ "Device auxiliary methods", "group___aux___q_o_dev.html", "group___aux___q_o_dev" ]
];
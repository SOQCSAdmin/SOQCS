var group___q_o_dev___circuit__basic =
[
    [ "random_circuit", "group___q_o_dev___circuit__basic.html#ga9c6b7790e1a399d9b145226b7710af00", null ],
    [ "NSX", "group___q_o_dev___circuit__basic.html#ga33425c954c5abd319fddb3e54e52a763", null ],
    [ "beamsplitter", "group___q_o_dev___circuit__basic.html#ga021cd91fa0f22abdc8906474702c8bf6", null ],
    [ "dielectric", "group___q_o_dev___circuit__basic.html#ga2792f308fc13a80703e9cca18b40d3d3", null ],
    [ "MMI2", "group___q_o_dev___circuit__basic.html#ga087d7708d41eccafcbe2e05a933ce059", null ],
    [ "rewire", "group___q_o_dev___circuit__basic.html#gaf5c230d0f4709dadf28d53636182191b", null ],
    [ "phase_shifter", "group___q_o_dev___circuit__basic.html#gaeeeb6b4f5d6fb248f29f290cc47519b8", null ],
    [ "loss", "group___q_o_dev___circuit__basic.html#ga688b6fa744e3392d40f4865012216fe0", null ],
    [ "dispersion", "group___q_o_dev___circuit__basic.html#ga752bb5d150a7ce9da78d442721203389", null ],
    [ "dispersion", "group___q_o_dev___circuit__basic.html#ga181a19a010f5b086a05579efd3a00ee4", null ],
    [ "delay", "group___q_o_dev___circuit__basic.html#ga6cdd127774f53bd08121da1c48bd5739", null ]
];
var group___bin__basic =
[
    [ "trace", "group___bin__basic.html#gac43c32c6e3acfe8f6a4d04427f17a357", null ],
    [ "normalize", "group___bin__basic.html#ga8dd3f362bc3e13b904d54d836b7ac59f", null ]
];
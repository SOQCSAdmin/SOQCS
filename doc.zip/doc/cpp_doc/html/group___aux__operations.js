var group___aux__operations =
[
    [ "prnt_in_rows", "group___aux__operations.html#ga6a9470400dbf6bff7d70292e9cda1782", null ],
    [ "prnt_in_cols", "group___aux__operations.html#gadff6e5c233a61aa94e2f3d8fa4ee1ca8", null ]
];
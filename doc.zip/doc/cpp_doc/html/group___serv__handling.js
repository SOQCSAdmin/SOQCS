var group___serv__handling =
[
    [ "send_work", "group___serv__handling.html#ga07fd0d83e2e2057faff4db726addf2f7", null ],
    [ "receive_work", "group___serv__handling.html#ga2897a9c2fc6b675f8ecb37ae80b67c7a", null ],
    [ "new_thread", "group___serv__handling.html#ga1c2b5558328fe38d024f2391229639f9", null ]
];
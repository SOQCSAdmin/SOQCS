var group___serv__handling =
[
    [ "send_work", "group___serv__handling.html#ga3275d9ce4fb9199d6dbb5da64f103e71", null ],
    [ "receive_work", "group___serv__handling.html#ga2897a9c2fc6b675f8ecb37ae80b67c7a", null ],
    [ "new_thread", "group___serv__handling.html#ga2c53563f33bd92e47bd17a75c321aad5", null ]
];
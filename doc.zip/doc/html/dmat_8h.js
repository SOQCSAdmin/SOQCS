var dmat_8h =
[
    [ "DEFMATDIM", "dmat_8h.html#a6d467377849536303d7d27a7c3fab457", null ],
    [ "DEFWIDTH", "dmat_8h.html#a37657f8f22181c41024f1d7d1d4b8a7e", null ]
];
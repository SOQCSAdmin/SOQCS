var group___circuit__elements =
[
    [ "Basic circuit elements", "group___circuit__basic.html", "group___circuit__basic" ],
    [ "Polarization circuit elements", "group___circuit__polar.html", "group___circuit__polar" ],
    [ "Emission and distinguishability model", "group___circuit__distin.html", "group___circuit__distin" ],
    [ "Detectors", "group___circuit__detector.html", "group___circuit__detector" ]
];
var group___circuit__basic =
[
    [ "random_circuit", "group___circuit__basic.html#gac03ff5a3314367d71d0582462c93f90b", null ],
    [ "NSX", "group___circuit__basic.html#gab07f26a3edee94d43dee25f9243c7022", null ],
    [ "beamsplitter", "group___circuit__basic.html#gac02f79267b58e219a65e4baf25410e28", null ],
    [ "dielectric", "group___circuit__basic.html#ga12d017d5f3380dd6d4e91836458206d7", null ],
    [ "MMI2", "group___circuit__basic.html#gad088cb78f37775486a83b038bb79fea2", null ],
    [ "phase_shifter", "group___circuit__basic.html#ga42a4f680611df9e3605c7fd42dbb3e75", null ],
    [ "phase_shifter", "group___circuit__basic.html#gaf3549564c11a90b859a3807098b35e62", null ],
    [ "loss", "group___circuit__basic.html#ga3b9441da86651a4270cf3db84afae9db", null ],
    [ "custom_gate", "group___circuit__basic.html#gaa85f6698cb6531924ccbb8f187f1afbc", null ]
];
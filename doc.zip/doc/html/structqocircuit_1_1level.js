var structqocircuit_1_1level =
[
    [ "ch", "structqocircuit_1_1level.html#a7d257b11bc4796a0c0eee6b09b5d1a33", null ],
    [ "m", "structqocircuit_1_1level.html#a3d63eb4fc4c8440f6769f760d419d51b", null ],
    [ "s", "structqocircuit_1_1level.html#a91c3703677d5de98865baa2492d074a4", null ]
];
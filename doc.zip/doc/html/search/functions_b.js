var searchData=
[
  ['loss',['loss',['../group___circuit__basic.html#ga3b9441da86651a4270cf3db84afae9db',1,'qocircuit']]]
];

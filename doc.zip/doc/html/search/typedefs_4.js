var searchData=
[
  ['vecc',['vecc',['../util_8h.html#a3a31fa545f90c8e441dcb95b0b3ff583',1,'util.h']]],
  ['vecd',['vecd',['../util_8h.html#a918b4d659e0bad7b09178d678044beaa',1,'util.h']]],
  ['veci',['veci',['../util_8h.html#a770b592acd5ace4ded2cdf12685b480d',1,'util.h']]]
];

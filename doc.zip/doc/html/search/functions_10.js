var searchData=
[
  ['rand',['Rand',['../classstate.html#a743a0545a25178e011f17274d6efa730',1,'state']]],
  ['random_5fcircuit',['random_circuit',['../group___circuit__basic.html#gac03ff5a3314367d71d0582462c93f90b',1,'qocircuit']]],
  ['receive_5fwork',['receive_work',['../group___serv__handling.html#ga2897a9c2fc6b675f8ecb37ae80b67c7a',1,'mthread']]],
  ['remove_5ffreq',['remove_freq',['../group___bin__manipulation.html#gaf681b15613837e6797d28d1b4e93fce7',1,'p_bin']]],
  ['remove_5ftime',['remove_time',['../group___ket__operations.html#ga2cfef733588e95185ac0d03d98dc9e72',1,'ket_list::remove_time()'],['../group___bin__manipulation.html#ga63a9ea8ebf40d92ae77a296fc16b1f45',1,'p_bin::remove_time()']]],
  ['reset',['reset',['../group___circuit__management.html#ga649562443c8727bb4431772f03d4dc5a',1,'qocircuit']]],
  ['return_5fpacket_5fdef',['return_packet_def',['../group___photonmdl__utility.html#ga653f3bcda2d02cdad9c6bb0b642dbd8c',1,'photon_mdl']]],
  ['rotator',['rotator',['../group___circuit__polar.html#gaae01425daab16d5bfa960bb5b2170eff',1,'qocircuit']]],
  ['run',['run',['../group___simulation__execution.html#ga0cc6f53e48056281735d2af68a266955',1,'simulator::run(ph_bunch *input, qocircuit *qoc)'],['../group___simulation__execution.html#gae0f4d9cb28e4bdb76dd95c46dab695f0',1,'simulator::run(state *istate, qocircuit *qoc)'],['../group___simulation__execution.html#gaa697512a8b6d3e023472c1e04e97fa30',1,'simulator::run(state *istate, ket_list *olist, qocircuit *qoc)']]]
];

var searchData=
[
  ['flag_5fprnt',['flag_prnt',['../classqocircuit.html#a940093e761603714b4358e8930f88cf7',1,'qocircuit']]],
  ['freq',['freq',['../classphoton__mdl.html#a21388731bb22d237aaf05c0a4c9f9ee1',1,'photon_mdl']]]
];

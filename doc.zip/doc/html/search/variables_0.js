var searchData=
[
  ['ampl',['ampl',['../classstate.html#a79b27c475429045fb087e450dbfdd316',1,'state']]]
];

var searchData=
[
  ['sample',['sample',['../group___simulation__execution.html#ga8d70bf5b838b3b28d20ab3e582138728',1,'simulator::sample(ph_bunch *input, qocircuit *qoc, int N)'],['../group___simulation__execution.html#ga7c1bcb9d5202eb607f776720fc465b79',1,'simulator::sample(state *istate, qocircuit *qoc, int N)']]],
  ['send2circuit',['send2circuit',['../group___p_bunch__manipulation.html#gad5bc1d868ff9ac870c99052069122e01',1,'ph_bunch::send2circuit(qocircuit *qoc)'],['../group___p_bunch__manipulation.html#ga997fc74511fa9f9275cc8fbe3ddc5bd9',1,'ph_bunch::send2circuit(char ckind, int rand, qocircuit *qoc)']]],
  ['send_5fwork',['send_work',['../group___serv__handling.html#ga07fd0d83e2e2057faff4db726addf2f7',1,'mthread']]],
  ['set_5fprnt_5fflag',['set_prnt_flag',['../group___circuit__print.html#ga9fa523baa9fecccccb2dacd730556901',1,'qocircuit']]],
  ['simulator',['simulator',['../group___simulation__management.html#ga1ab0fbd888353e9769fda14ffe5394ac',1,'simulator::simulator()'],['../group___simulation__management.html#ga8fd5544b51c788141b9bfcc2941a3957',1,'simulator::simulator(int i_backend, int i_mem)'],['../group___simulation__management.html#ga628613ca772e5c18948f08484e84bb7b',1,'simulator::simulator(const char *i_back, int i_mem)']]],
  ['state',['state',['../group___state__management.html#gae8b53ef5d217e9ada281315b581478f4',1,'state::state(int i_level)'],['../group___state__management.html#ga47b60384603ef3f7210b2bf0a11f8ca9',1,'state::state(int i_level, int i_maxket)'],['../group___state__management.html#gac97ad13db9cd9c137717587ffdf25d88',1,'state::state(int i_level, int i_maxket, int *i_vis)']]],
  ['str2int',['str2int',['../util_8h.html#ab29c200876205c3add1d71f053195658',1,'util.h']]],
  ['sum_5fstate',['sum_state',['../group___dens__update.html#ga388a45ac722aac46715ef9b8df195d53',1,'dmatrix']]]
];

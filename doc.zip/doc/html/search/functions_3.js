var searchData=
[
  ['dark_5fcounts',['dark_counts',['../group___bin__manipulation.html#gaa1a6aae130f27e37ebd4b4f7f803940b',1,'p_bin']]],
  ['def_5fpacket',['def_packet',['../group___circuit__distin.html#gaa64241011a67e554e34c48258f7c3a7f',1,'qocircuit']]],
  ['delay',['delay',['../group___circuit__distin.html#gaf8fd23c0d731bdd44b7df3f423e02fd7',1,'qocircuit::delay(int ch, double dt)'],['../group___circuit__distin.html#ga5f3f0a67a92c9ac7e4d6b738ffb2f20d',1,'qocircuit::delay(int ch, double dt, photon_mdl *mdl)'],['../group___circuit__distin.html#gaaf8d4888e5ea60acd16ddd70bcfc74b6',1,'qocircuit::delay(int i_ch, matc T, int nT)']]],
  ['detector',['detector',['../group___circuit__detector.html#ga70a7f02c4a7806b1824d8e0d24acb96e',1,'qocircuit::detector(int i_ch)'],['../group___circuit__detector.html#ga4a10089a5acc4a6ccda29d84252a97c4',1,'qocircuit::detector(int i_ch, int cond)'],['../group___circuit__detector.html#ga65008511fa18f73da2aca8319864e54b',1,'qocircuit::detector(int i_ch, int cond, double eff, double blnk, double gamma)']]],
  ['dielectric',['dielectric',['../group___circuit__basic.html#ga12d017d5f3380dd6d4e91836458206d7',1,'qocircuit']]],
  ['directf',['DirectF',['../group___simulation__auxiliary.html#gab8453ff83d6257f56c758b2e77f1c962',1,'simulator']]],
  ['directr',['DirectR',['../group___simulation__auxiliary.html#gaa83d178da21de43fd034071d7c46590e',1,'simulator']]],
  ['directs',['DirectS',['../group___simulation__auxiliary.html#ga0447bf1e60ac43aec064c57e87a48ca3',1,'simulator']]],
  ['dmatrix',['dmatrix',['../group___dens__management.html#ga7ace3d2d0e9c7c13e841a7a9911af7d5',1,'dmatrix::dmatrix()'],['../group___dens__management.html#ga7d87792e72520772eb0b0837331e5357',1,'dmatrix::dmatrix(int i_mem)']]],
  ['dproduct',['dproduct',['../group___state__operations.html#ga73039e7aa3f6e0b0b5206309c8e3584e',1,'state']]]
];

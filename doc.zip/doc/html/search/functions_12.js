var searchData=
[
  ['tag',['tag',['../group___bin__consult.html#gaeca95124b60fef804a4beccd43ea63ee',1,'p_bin']]],
  ['trace',['trace',['../group___dens__basic.html#ga26e672772c1e94176db41ce3944e5bb8',1,'dmatrix']]]
];

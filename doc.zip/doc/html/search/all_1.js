var searchData=
[
  ['backend',['backend',['../classsimulator.html#a9c83d98065d7663cb173bf5a3666dd25',1,'simulator']]],
  ['base',['base',['../util_8cpp.html#a19437a5875428e719515fb20de8a6927',1,'base():&#160;util.cpp'],['../util_8h.html#a19437a5875428e719515fb20de8a6927',1,'base():&#160;util.cpp']]],
  ['beamsplitter',['beamsplitter',['../group___circuit__basic.html#gac02f79267b58e219a65e4baf25410e28',1,'qocircuit']]],
  ['bell',['Bell',['../classstate.html#ab5c229f8e97695ee4ee2acc0d2f7b5e3',1,'state']]],
  ['black',['BLACK',['../util_8h.html#a7b3b25cba33b07c303f3060fe41887f6',1,'util.h']]],
  ['blink',['blink',['../group___bin__manipulation.html#gaee1afbd446df627c66bfd7bea310c20e',1,'p_bin']]],
  ['blue',['BLUE',['../util_8h.html#a79d10e672abb49ad63eeaa8aaef57c38',1,'util.h']]],
  ['boldblack',['BOLDBLACK',['../util_8h.html#aef2fe95894117165b29036718221979f',1,'util.h']]],
  ['boldblue',['BOLDBLUE',['../util_8h.html#a11e77c19555cbd15bcc744ff36a18635',1,'util.h']]],
  ['boldcyan',['BOLDCYAN',['../util_8h.html#ae87af5e6363eb1913b17f24dcb60a22d',1,'util.h']]],
  ['boldgreen',['BOLDGREEN',['../util_8h.html#a4a6c893a1703c33ede7d702fe5f97c91',1,'util.h']]],
  ['boldmagenta',['BOLDMAGENTA',['../util_8h.html#ac4723c5ee12cfca16e2172b57b99cb07',1,'util.h']]],
  ['boldred',['BOLDRED',['../util_8h.html#ab912d02c7998c3d47d05f87be4e2c920',1,'util.h']]],
  ['boldwhite',['BOLDWHITE',['../util_8h.html#aa4ef051614aa0bd503b0a18ee158c5d7',1,'util.h']]],
  ['boldyellow',['BOLDYELLOW',['../util_8h.html#a8cec79108dfc3c61e8e32d390ec28b26',1,'util.h']]],
  ['braket',['braket',['../group___state__operations.html#ga76f0b7fa8bf77d76671c07dd6a451576',1,'state']]],
  ['bunch_5fstate',['bunch_state',['../group___p_bunch__manipulation.html#ga2cab4b5e71ac65f14044433fed21ebfd',1,'ph_bunch']]],
  ['basic_20circuit_20elements',['Basic circuit elements',['../group___circuit__basic.html',1,'']]],
  ['bunch_20state_20output',['Bunch state output',['../group___p_bunch__output.html',1,'']]]
];

var searchData=
[
  ['qoc',['qoc',['../structqelem.html#a3f4aa0ab9d3a83583be401802c6d9c5c',1,'qelem']]]
];

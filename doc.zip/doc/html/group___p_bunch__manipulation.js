var group___p_bunch__manipulation =
[
    [ "add_photons", "group___p_bunch__manipulation.html#gab0695d1c141c722931a030e4a83cf8c8", null ],
    [ "add_photons", "group___p_bunch__manipulation.html#gac02f454d8d68b3e0ebffaf6674b7493a", null ],
    [ "send2circuit", "group___p_bunch__manipulation.html#gad5bc1d868ff9ac870c99052069122e01", null ],
    [ "send2circuit", "group___p_bunch__manipulation.html#ga997fc74511fa9f9275cc8fbe3ddc5bd9", null ],
    [ "weight", "group___p_bunch__manipulation.html#gacf92948488b53378a627e305cb187a32", null ],
    [ "alternative", "group___p_bunch__manipulation.html#ga49147fef9802d0d4136a07b0192227e6", null ],
    [ "bunch_state", "group___p_bunch__manipulation.html#ga2cab4b5e71ac65f14044433fed21ebfd", null ]
];
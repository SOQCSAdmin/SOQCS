var state_8h =
[
    [ "hterm", "state_8h.html#ac382754610a4d1fd8caf75faa3a356f2", null ],
    [ "DEFSTATEDIM", "state_8h.html#adf1b9e021e28ece2dc2bf7aea43c5a58", null ],
    [ "DEFTHOLDPRNT", "state_8h.html#ae48fecb0e0b4379779138b3a0e3c39ae", null ]
];
var group___circuit__detector =
[
    [ "detector", "group___circuit__detector.html#ga70a7f02c4a7806b1824d8e0d24acb96e", null ],
    [ "detector", "group___circuit__detector.html#ga4a10089a5acc4a6ccda29d84252a97c4", null ],
    [ "detector", "group___circuit__detector.html#ga65008511fa18f73da2aca8319864e54b", null ],
    [ "noise", "group___circuit__detector.html#ga067a409ebaa03244c1bc76455bf0f2bf", null ]
];
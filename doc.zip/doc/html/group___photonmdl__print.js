var group___photonmdl__print =
[
    [ "prnt", "group___photonmdl__print.html#gaf79811b67fb375a694cd2ca0af8d1a39", null ],
    [ "prnt_times", "group___photonmdl__print.html#gaeaa1c5592a5e9c870843087023de7ab5", null ],
    [ "prnt_freqs", "group___photonmdl__print.html#ga8c51ab42f486f8af92a8e41970b878ad", null ],
    [ "prnt_packets", "group___photonmdl__print.html#ga90df42cedc408e7f290f10c06c3be521", null ]
];
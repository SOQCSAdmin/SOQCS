var group___dens__aux =
[
    [ "create_dmtx", "group___dens__aux.html#ga1294e8a21a5ece79f71371ae9412db02", null ],
    [ "ketcompatible", "group___dens__aux.html#ga99e528af505be8f9ef2d3a335ac7cfe6", null ]
];
var group___bin__manipulation =
[
    [ "calc_measure", "group___bin__manipulation.html#ga9e032eb3f559778b03b20223dada5682", null ],
    [ "post_selection", "group___bin__manipulation.html#ga223542c9aafd866eae7ec69d1d44fb2b", null ],
    [ "dark_counts", "group___bin__manipulation.html#gaa1a6aae130f27e37ebd4b4f7f803940b", null ],
    [ "blink", "group___bin__manipulation.html#gaee1afbd446df627c66bfd7bea310c20e", null ],
    [ "compute_loss", "group___bin__manipulation.html#gaa296777e9453ed9e60a91ed3fb298a9e", null ],
    [ "compute_cond", "group___bin__manipulation.html#ga5fca936e98d211cc676241a67a5e6934", null ],
    [ "remove_freq", "group___bin__manipulation.html#gaf681b15613837e6797d28d1b4e93fce7", null ],
    [ "perform_count", "group___bin__manipulation.html#gaff3ba66c2fd7081b12c6c21c23f1d293", null ],
    [ "remove_time", "group___bin__manipulation.html#ga63a9ea8ebf40d92ae77a296fc16b1f45", null ],
    [ "white_noise", "group___bin__manipulation.html#ga04228d9994367a202f5979569bc98427", null ]
];
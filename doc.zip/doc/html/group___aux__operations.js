var group___aux__operations =
[
    [ "prnt_in_rows", "group___aux__operations.html#gaa18fd5456b49f201cac79b9abb56707b", null ],
    [ "prnt_in_cols", "group___aux__operations.html#gac6cc916bbd7475ee095dd900039923c5", null ]
];